public interface MyObserver {
    void update(MyObservable o, Object arg);
}
