import java.util.*;
import java.util.concurrent.*;

public class BlockingQueueExamples {
  public static void main(String... args) {
    ArrayDeque ad = new ArrayDeque();
    ArrayBlockingQueue abq;
  }
}
